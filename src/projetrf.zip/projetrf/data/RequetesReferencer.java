/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package projetrf.data;

/**
 *
 * @author Travail
 */
public class RequetesReferencer {
    
}
